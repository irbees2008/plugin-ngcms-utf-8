<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
				<td>
				<img border="0" src="{{ tpl_url|e('html_attr') }}/images/2z_35.gif" width="7" height="36" /></td>
				<td style="background-image:url('{{ tpl_url|e('html_attr') }}/images/2z_36.gif');" width="100%">
				<font color="#FFFFFF"><b>&nbsp;Случайная цитата</b></font></td>
				<td>
				<img border="0" src="{{ tpl_url|e('html_attr') }}/images/2z_38.gif" width="7" height="36" /></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
				<td style="background-image:url('{{ tpl_url|e('html_attr') }}/images/2z_56.gif');" width="7">&nbsp;</td>
				<td bgcolor="#FFFFFF"><ul>{{ entries|raw }}</ul></td>
				<td style="background-image:url('{{ tpl_url|e('html_attr') }}/images/2z_58.gif');" width="7">&nbsp;</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
				<td>
				<img border="0" src="{{ tpl_url|e('html_attr') }}/images/2z_60.gif" width="7" height="11" /></td>
				<td style="background-image:url('{{ tpl_url|e('html_attr') }}/images/2z_61.gif');" width="100%"></td>
				<td>
				<img border="0" src="{{ tpl_url|e('html_attr') }}/images/2z_62.gif" width="7" height="11" /></td>
			</tr>
		</table>
		</td>
	</tr>
</table>

